#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <stddef.h>
#include <bitmap.h>
#include <hash.h>
#include <list.h>
#include "devices/block.h"
#include "threads/synch.h"
#include "threads/vaddr.h"

extern struct lock swap_lock;    /* prevents data race in swap_map. */
extern struct bitmap *swap_map;  /* bitmap of swap slots.*/
extern struct block *swap_block;

void swap_init (void);
void swap_in (size_t swap_slot, void* kaddr);
size_t swap_out (void* kaddr);
void swap_free (size_t swap_slot);

#endif
