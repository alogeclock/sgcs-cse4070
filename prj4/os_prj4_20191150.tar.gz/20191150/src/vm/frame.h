#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <list.h>
#include <stdlib.h>
#include <bitmap.h>
#include "threads/palloc.h"
#include "threads/synch.h"
#include "userprog/pagedir.h"
#include "vm/page.h"
#include "vm/swap.h"

extern struct list frame_table;
extern struct lock frame_table_lock;
extern struct list_elem* clock;

/* entry of frame table */
struct frame {
    void *kaddr; /* physical address of frame (kernel address) */
    struct spt_entry *spte; /* spt_entry for the frame */
    struct thread *thread;  /* owner thread of frame */
    struct list_elem elem;  /* list element for frame table */
    bool pinned;
};

void frame_init (void);
struct frame *palloc_frame (enum palloc_flags flags, struct spt_entry *spte);
void remove_frame (struct list_elem *e);
void free_frame (void *kpage);
void evict_frame (void);

#endif
