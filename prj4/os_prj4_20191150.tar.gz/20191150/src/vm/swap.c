#include "vm/swap.h"

/* PGSIZE: 4096,
   BLOCK_SECTOR_SIZE: 512 bytes
   SECTORS_PER_PAGE: 8 (default) */
#define SECTORS_PER_PAGE (PGSIZE / BLOCK_SECTOR_SIZE)

struct lock swap_lock;    /* prevents data race in swap_map. */
struct bitmap* swap_map;  /* bitmap of swap slots.*/
struct block* swap_block;

/* initializes data structures of swap space.*/
void
swap_init(void)
{
  lock_init(&swap_lock);
  swap_block = block_get_role(BLOCK_SWAP);
  if (swap_block == NULL)
  {
    PANIC("swap block is not allocated!");
    return;
  }

  /* Initialize swap_map.
     The size is the number of pages that can fit in the swap device. */
  swap_map = bitmap_create(block_size(swap_block) / SECTORS_PER_PAGE);
  if (swap_map == NULL) {
    PANIC("swap map is not allocated!");
    return;
  }
  
  bitmap_set_all(swap_map, 0); // All slots are free initially
}

/* reads data of swap_slot and writes to main memory (kpage) */
void
swap_in(size_t swap_slot, void* kaddr)
{
  lock_acquire(&swap_lock);

  /* if the slot is actually used, releases lock and return */
  if (bitmap_test(swap_map, swap_slot) == false) {
    lock_release(&swap_lock);
    return;
  }

  /* read sectors from disk and writes to main memory */
  for (int i = 0; i < SECTORS_PER_PAGE; i++) {
    size_t block_sector_slot = swap_slot * SECTORS_PER_PAGE + i;
    block_read(swap_block, block_sector_slot, (uint8_t *)kaddr + (i * BLOCK_SECTOR_SIZE));
  }

  /* mark the slot as free */
  bitmap_flip(swap_map, swap_slot);

  lock_release(&swap_lock);
}

/* writes KPAGE to the swap slot, and returns the swap slot. */
size_t
swap_out(void* kaddr)
{
  lock_acquire(&swap_lock);

  /* find a free slot */
  size_t free_slot = bitmap_scan_and_flip(swap_map, 0, 1, false);

  if (free_slot == BITMAP_ERROR) {
    lock_release(&swap_lock);
    return BITMAP_ERROR;
  }

  for (int i = 0; i < SECTORS_PER_PAGE; i++) {
    size_t block_sector_slot = free_slot * SECTORS_PER_PAGE + i;
    block_write(swap_block, block_sector_slot, (uint8_t *)kaddr + (i * BLOCK_SECTOR_SIZE));
  }

  lock_release(&swap_lock);
  return free_slot;
}

void
swap_free (size_t swap_slot)
{
  lock_acquire (&swap_lock);
  if (bitmap_test(swap_map, swap_slot)) {
    bitmap_set(swap_map, swap_slot, false);
  }
  lock_release (&swap_lock);
}