#include "vm/frame.h"

struct list frame_table;
struct lock frame_table_lock;
struct list_elem *clock;

void
frame_init (void)
{
  list_init (&frame_table);
  lock_init (&frame_table_lock);
  clock = NULL;
}

struct frame*
find_frame(void* kaddr)
{
  lock_acquire(&frame_table_lock);
  struct list_elem* e = list_begin (&frame_table);
  while (e != list_end (&frame_table))
  {
    struct frame* f = list_entry(e, struct frame, elem);
    if (f->kaddr == kaddr) {
      lock_release(&frame_table_lock);
      return f;
    }
    e = list_next (e);
  }
  lock_release(&frame_table_lock);
  return NULL;
}

/* allocates frame and inserts its elem to the frame table */
struct frame*
palloc_frame (enum palloc_flags flags, struct spt_entry* spte)
{
  /* if not user page requests, returns NULL */
  if ((flags & PAL_USER) == 0)
    return NULL;

  /* allocates a page (physical memory) by flags */
  void *kaddr = palloc_get_page (flags);
  if (kaddr == NULL) /* main memory is full, so evict pages */
  { 
    while (kaddr == NULL) {
      evict_frame ();
      kaddr = palloc_get_page (flags);
    }
  }

  /* inserts frame in frame table */
  struct frame *frame = malloc (sizeof (struct frame));
  if (frame == NULL)
  {
    palloc_free_page (kaddr);
    return NULL;
  }

  frame->kaddr = kaddr;
  frame->spte = spte;
  frame->thread = thread_current ();
  frame->pinned = false;

  lock_acquire (&frame_table_lock);
  list_push_back (&frame_table, &frame->elem);
  lock_release (&frame_table_lock);

  return frame;
}

void
remove_frame (struct list_elem *e)
{
  if (clock == e) 
  {
    clock = list_next (e);
  
    /* if clock points end of the frame table, 
      set clock as begin of the frame table */
    if (clock == list_end (&frame_table))
      clock = list_begin (&frame_table);

    if (clock == e)
      clock = NULL;
  }

  list_remove (e);
}

void
free_frame (void* kaddr)
{
  lock_acquire (&frame_table_lock);

  struct list_elem *e = list_begin (&frame_table);
  while (e != list_end (&frame_table))
  {
    struct frame *frame = list_entry (e, struct frame, elem);
    if (frame->kaddr == kaddr)
    {
      remove_frame (&frame->elem);
      palloc_free_page(kaddr);
      free (frame);
      break;
    }
    e = list_next (e);
  }

  lock_release (&frame_table_lock);
}

/* evicts frame and returns physical page address */
void
evict_frame (void)
{
  lock_acquire (&frame_table_lock);

  /* check frame table is not empty */
  if (list_empty (&frame_table))
  {
    lock_release (&frame_table_lock);
    return;
  }
  
  if (clock == NULL || clock == list_end (&frame_table))
    clock = list_begin (&frame_table);

  /* second-chance algorithm */
  while (true) 
  {
    if (clock == list_end (&frame_table))
      clock = list_begin (&frame_table);

    struct frame *frame = list_entry (clock, struct frame, elem);
    struct thread *thread = frame->thread;
    struct spt_entry *spte = frame->spte;

    clock = list_next(clock);

    /* if pinned frame, pass */
    if (frame->pinned)
      continue;

    /* if pagedir is accessed, then reset accessed bit and pass */
    if (pagedir_is_accessed (thread->pagedir, spte->vaddr))
      pagedir_set_accessed (thread->pagedir, spte->vaddr, false);

    /* if pagedir is not accessed, evicts frame to the swap space */
    else 
    {
      /* check dirty bit and frees the page */
      bool is_dirty = pagedir_is_dirty (thread->pagedir, spte->vaddr);

      list_remove(&frame->elem);
      lock_release(&frame_table_lock);

      /* if clean BIN, just frees the frame,
        if not (dirty BIN, user stack, etc.), swap out to the disk. */
      if (spte->type == SPT_SWAP || is_dirty)
      {
        if (spte->type == SPT_BIN) 
        {
          spte->type = SPT_SWAP;
          file_close(spte->file);
        }
        spte->swap_slot = swap_out (frame->kaddr);
      }

      pagedir_clear_page(thread->pagedir, spte->vaddr);
      spte->loaded = false; /* removes frame from the main memory */
  
      palloc_free_page(frame->kaddr);
      free (frame);

      return;
    }
  }
}