#include "vm/page.h"

static unsigned
spt_hash_func (const struct hash_elem* e, void* aux UNUSED)
{
  struct spt_entry *spte = hash_entry (e, struct spt_entry, elem);
  return hash_int ((int)spte->vaddr);
}

static bool
spt_less_func (const struct hash_elem* a,
               const struct hash_elem* b,
               void* aux UNUSED)
{
  struct spt_entry *spte_a = hash_entry (a, struct spt_entry, elem);
  struct spt_entry *spte_b = hash_entry (b, struct spt_entry, elem);

  return spte_a->vaddr < spte_b->vaddr;
}

static void
spt_destroy_func (struct hash_elem* e, void* aux)
{
  struct spt_entry *spte = hash_entry (e, struct spt_entry, elem);
  struct thread *t = thread_current ();

  /* check page of spt_entry is loaded to main memory */
  if (spte->loaded)
  {
    /* kernel virtual address of physical frame */
    void *kaddr = pagedir_get_page (t->pagedir, spte->vaddr);
    free_frame (kaddr); /* frees physical page */
    pagedir_clear_page(t->pagedir, spte->vaddr); /* disables PTE mapping */
  }

  /* page is in swap space */
  else if (spte->type == SPT_SWAP)
    swap_free(spte->swap_slot);

  /* if page has open file, close it*/
  if (spte->type == SPT_BIN && spte->file != NULL)
    file_close(spte->file);
  
  free (spte);
}

void
spt_init (struct hash* spt)
{
  /* initializes SPT with spt_hash_func and spt_less_func */
  hash_init (spt, spt_hash_func, spt_less_func, NULL);
  return;
}

void
spt_destroy (struct hash* spt)
{
  /* destroys SPT with spt_destroy_func. */
  hash_destroy (spt, spt_destroy_func);
}

struct spt_entry*
create_spt_stack_entry (void *vaddr)
{
  struct spt_entry *entry = malloc (sizeof (struct spt_entry));
  if (entry == NULL)
    return NULL;

  entry->vaddr = pg_round_down (vaddr);
  entry->type = SPT_SWAP;
  entry->writable = true;
  entry->loaded = true;
  entry->swap_slot = (size_t)-1;

  return entry;
}

bool
insert_spt_entry (struct hash* spt, struct spt_entry* spte)
{
  struct hash_elem *elem = hash_insert (spt, &spte->elem);
  return elem == NULL;
}

struct spt_entry*
find_spt_entry (void* vaddr)
{
  struct thread* t = thread_current();
  struct spt_entry spte;
  spte.vaddr = pg_round_down (vaddr);

  struct hash_elem *e = hash_find (&t->spt, &spte.elem);
  if (e == NULL)
    return NULL;

  return hash_entry (e, struct spt_entry, elem);
}
