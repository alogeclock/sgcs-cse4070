#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include <string.h>
#include <stdlib.h>
#include "threads/thread.h"
#include "threads/vaddr.h"

enum spt_type {
    SPT_BIN, 
    SPT_SWAP
};

/* Supplement Page Table */
struct spt_entry {
    /* page type and virtual address */
    uint8_t type;     /* page type */
    void *vaddr;      /* virtual address */
    
    /* Flags of PTEs */
    bool writable;    /* read-only or read/write */
    bool loaded;      /* loaded to main memory now */

    /* file system information */
    struct file *file;  /* memory-mapped file pointer of entry */
    size_t offset;      /* file offset (read/write) */
    size_t read_bytes;  /* bytes to read */
    size_t zero_bytes;  /* bytes to fill as 0 */
    size_t swap_slot;   /* swap slot indices */

    /* hash table(SPT) element */
    struct hash_elem elem;
};

void spt_init (struct hash *spt);
void spt_destroy (struct hash *spt);

struct spt_entry* create_spt_stack_entry (void *vaddr);
bool insert_spt_entry (struct hash *spt, struct spt_entry *spte);
struct spt_entry *find_spt_entry (void *vaddr);

#endif